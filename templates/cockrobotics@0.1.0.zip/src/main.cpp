/**
 * This template is created for Gamecock Robotics at the University of South Carolina
 * Thats about it... :D
*/

#include "main.h"

void initialize() {}

void disabled() {}

void competition_initialize() {}

void autonomous() {}

void opcontrol() {
	pros::Controller master(pros::E_CONTROLLER_MASTER);
	pros::MotorGroup left_mg({1, -2, 3});
	pros::MotorGroup right_mg({-4, 5, -6});

	while (true) {
		//Code here

		pros::delay(20); // MUST LEAVE THIS
	}
}